<?php $__env->startSection('content'); ?>

<div class="row">
   <div class="col-md-12 p-5" >
        <div class="pagenotfound text-center">
            <img src="https://wirelessprinter.online/upload/medai/64900991a6ef4404.png" alt="404 page" class="img-fluid mb-3">
            <h1 class="mb-3"> Page Not Found</h1>
            <p> We're Sorry, the page you requested could not be found <br/> Please go back to the home</p>
            <a class="btn btn-info text-light" href="<?php echo e(route('home')); ?>" >Back To Home</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>
    const a = setTimeout( ()=>{
        location.href="<?php echo e(route('home')); ?>"
    }, 4000)
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/wirelessprinter/connectprintertowifi.com/resources/views/errors/404.blade.php ENDPATH**/ ?>