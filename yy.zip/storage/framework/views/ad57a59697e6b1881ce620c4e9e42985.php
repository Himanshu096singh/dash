<?php $__env->startSection('content'); ?>

<section>
	<div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-6 col-lg-7 col-md-9 text-center">
                <div class="error_txt text_default">404</div>
                <div class="heading_s2 mb-2">
                	<h5>oops! The page you requested was not found!</h5> 
                </div>
                <p>The page you are looking for was moved, removed, renamed or might never existed.</p>
                <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-black">Back To Home</a>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>
    setTimeout( ()=>{
        location.href="<?php echo e(route('home')); ?>"
    }, 4000)
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\yy\resources\views/errors/404.blade.php ENDPATH**/ ?>