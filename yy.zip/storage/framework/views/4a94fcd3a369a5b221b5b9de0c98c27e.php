<?php $__env->startSection('content'); ?>
<!-- BEGIN : Main Content-->
<div class="main-content">
   <div class="content-overlay"></div>
   <div class="content-wrapper">
      <div class="row">
         <div class="col-12">
            <div class="content-header">
               Workshop
            </div>
         </div>
      </div>
      <section id="basic-hidden-label-form-layouts">
         <div class="row match-height">
            <div class="col-lg-12 col-md-12 col-12">
               <div class="card">
                  <div class="card-header">
                     <h4 class="card-title">Edit Workshop</h4>
                     <a href="<?php echo e(route('workshop.index')); ?>" class="btn gradient-purple-bliss shadow-z-1-hover float-right"><i class="ft-eye"></i> View Workshop</a>
                  </div>
                  <?php
                  $eid = Crypt::encrypt($workshop->id);
                  ?>
                  <div class="card-content">
                     <div class="card-body">
                        <form method="post" action="<?php echo e(route('workshop.update', $eid)); ?>" enctype="multipart/form-data">
                           <?php echo csrf_field(); ?>
                           <?php echo method_field('PATCH'); ?>
                           <div class="form-row">
                              <div class="col-md-6 col-12">
                                 <div class="form-group mb-2">
                                    <label for="name">Name</label>
                                    <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" type="text" placeholder="Name" value="<?php echo e(old('name', $workshop->name)); ?>">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                              </div>
                              <div class="col-md-6 col-12">
                                 <div class="form-group mb-2">
                                    <label for="slug">Slug</label>
                                    <input class="form-control <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="slug" name="slug" type="text" placeholder="Slug" value="<?php echo e(old('slug', $workshop->slug)); ?>">
                                    <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                              </div>
                              <div class="col-md-6 col-12">
                                 <div class="form-group mb-2">
                                    <label for="duration">Workshop Duration (Day)</label>
                                    <input class="form-control <?php $__errorArgs = ['duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="duration" name="duration" type="text" placeholder="15 Days" value="<?php echo e(old('duration',$workshop->duration)); ?>">
                                    <?php $__errorArgs = ['duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                              </div>
                              <div class="col-md-6 col-12">
                                 <div class="form-group mb-2">
                                    <label for="session">Workshop Session</label>
                                    <input class="form-control <?php $__errorArgs = ['session'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="session" name="session" type="text" placeholder="200 Hr" value="<?php echo e(old('session',$workshop->session)); ?>">
                                    <?php $__errorArgs = ['session'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                              </div>
                              <div class="col-md-6 col-12">
                                 <div class="form-group mb-2">
                                    <label for="onlineprice">Online Workshop Fees(in USD)</label>
                                    <input class="form-control <?php $__errorArgs = ['onlineprice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="onlineprice" name="onlineprice" type="number" min="0" placeholder="299" value="<?php echo e(old('onlineprice',$workshop->onlineprice)); ?>">
                                    <?php $__errorArgs = ['onlineprice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                              </div>
                              <div class="col-md-6 col-12">
                                 <div class="form-group mb-2">
                                    <label for="inpersonprice">Inperson Workshop Fees(in USD)</label>
                                    <input class="form-control <?php $__errorArgs = ['inpersonprice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="inpersonprice" name="inpersonprice" type="number" min="0" placeholder="399" value="<?php echo e(old('inpersonprice',$workshop->inpersonprice)); ?>">
                                    <?php $__errorArgs = ['inpersonprice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                              </div>
                                
                                <div class="col-md-12">
                                    <table class="table table-striped table-bordered">
                                        
                                        <tr>
                                            <td>
                                                1.
                                            </td>
                                            <td>
                                                <img src="<?php echo e(asset($workshop->image)); ?>" class="img-fluid rounded-top" alt="<?php echo e($workshop->item); ?>" width="100">
                                            </td>
                                            <td>
                                                <div class="form-group">
                                                    <label for="image d-block">Workshop Image (600x450px)</label> 
                                                    <br/>
                                                    <div class="custom-file">
                                                       <input type="file" class="custom-file-input" id="inputGroupFile01" <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  name="image">
                                                       <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                       <span class="invalid-feedback" role="alert">
                                                       <strong><?php echo e($message); ?></strong>
                                                       </span>
                                                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                       <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                                    </div>
                                                 </div>
                                            </td>
                                            <td>
                                                <div class="form-group mb-2">
                                                    <label for="alt">Alt</label>
                                                    <input class="form-control <?php $__errorArgs = ['alt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alt" name="alt" type="text" placeholder="Alt" value="<?php echo e(old('alt', $workshop->alt )); ?>">
                                                    <?php $__errorArgs = ['alt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                2.
                                            </td>
                                            <td>
                                                <img src="<?php echo e(asset($workshop->image2)); ?>" class="img-fluid rounded-top" width="100">
                                            </td>
                                            <td>
                                                <div class="form-group">
                                                    <label for="image d-block">Workshop Image (400x300px)</label> 
                                                    <br/>
                                                    <div class="custom-file">
                                                       <input type="file" class="custom-file-input" id="inputGroupFile01" <?php $__errorArgs = ['image2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> name="image2">
                                                       <?php $__errorArgs = ['image2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                       <span class="invalid-feedback" role="alert">
                                                       <strong><?php echo e($message); ?></strong>
                                                       </span>
                                                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                       <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                                    </div>
                                                 </div>
                                            </td>
                                            <td>
                                                <div class="form-group mb-2">
                                                    <label for="alt2">Alt</label>
                                                    <input class="form-control <?php $__errorArgs = ['alt2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alt2" name="alt2" type="text" placeholder="Alt" value="<?php echo e(old('alt2', $workshop->alt2 )); ?>">
                                                    <?php $__errorArgs = ['alt2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                3.
                                            </td>
                                            <td>
                                                <img src="<?php echo e(asset($workshop->image3)); ?>" class="img-fluid rounded-top" width="100">
                                            </td>
                                            <td>
                                                <div class="form-group">
                                                    <label for="image d-block">Workshop Image(400x300px)</label> 
                                                    <br/>
                                                    <div class="custom-file">
                                                       <input type="file" class="custom-file-input" id="inputGroupFile01" <?php $__errorArgs = ['image3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  name="image3">
                                                       <?php $__errorArgs = ['image3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                       <span class="invalid-feedback" role="alert">
                                                       <strong><?php echo e($message); ?></strong>
                                                       </span>
                                                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                       <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                                    </div>
                                                 </div>
                                            </td>
                                            <td>
                                                <div class="form-group mb-2">
                                                    <label for="alt3">Alt</label>
                                                    <input class="form-control <?php $__errorArgs = ['alt3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alt3" name="alt3" type="text" placeholder="Alt" value="<?php echo e(old('alt3', $workshop->alt3 )); ?>">
                                                    <?php $__errorArgs = ['alt3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                4.
                                            </td>
                                            <td>
                                                <img src="<?php echo e(asset($workshop->image4)); ?>" class="img-fluid rounded-top" width="100">
                                            </td>
                                            <td>
                                                <div class="form-group">
                                                    <label for="image d-block">Workshop Image (400x350px)</label> 
                                                    <br/>
                                                    <div class="custom-file">
                                                       <input type="file" class="custom-file-input" id="inputGroupFile01" <?php $__errorArgs = ['image4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> name="image4">
                                                       <?php $__errorArgs = ['image4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                       <span class="invalid-feedback" role="alert">
                                                       <strong><?php echo e($message); ?></strong>
                                                       </span>
                                                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                       <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                                    </div>
                                                 </div>
                                            </td>
                                            <td>
                                                <div class="form-group mb-2">
                                                    <label for="alt">Alt</label>
                                                    <input class="form-control <?php $__errorArgs = ['alt4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alt4" name="alt4" type="text" placeholder="Alt" value="<?php echo e(old('alt4', $workshop->alt4 )); ?>">
                                                    <?php $__errorArgs = ['alt4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                5.
                                            </td>
                                            <td>
                                                <img src="<?php echo e(asset($workshop->image5)); ?>" class="img-fluid rounded-top" width="100">
                                            </td>
                                            <td>
                                                <div class="form-group">
                                                    <label for="image d-block">Workshop Image (400x350px)</label> 
                                                    <br/>
                                                    <div class="custom-file">
                                                       <input type="file" class="custom-file-input" id="inputGroupFile01" <?php $__errorArgs = ['image5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> name="image5">
                                                       <?php $__errorArgs = ['image5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                       <span class="invalid-feedback" role="alert">
                                                       <strong><?php echo e($message); ?></strong>
                                                       </span>
                                                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                       <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                                                    </div>
                                                 </div>
                                            </td>
                                            <td>
                                                <div class="form-group mb-2">
                                                    <label for="alt">Alt</label>
                                                    <input class="form-control <?php $__errorArgs = ['alt5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alt5" name="alt5" type="text" placeholder="Alt" value="<?php echo e(old('alt5', $workshop->alt5 )); ?>">
                                                    <?php $__errorArgs = ['alt5'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>


                              <div class="colo-md-12 col-lg-12 col-12">
                                 <div class="form-group mb-2">
                                    <label for="about">About</label>
                                    <textarea class="form-control <?php $__errorArgs = ['about'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="description" name="about" rows="4"><?php echo e(old('about', $workshop->about)); ?></textarea>
                                    <?php $__errorArgs = ['about'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                              </div>
                           </div>
                           <hr/>
                           <div class="my-3">
                              <h4 class="card-title">SEO (Meta Details)</h4>
                           </div>
                           <div class="form-row">
                              <div class="col-md-6 col-12">
                                 <div class="form-group mb-2">
                                    <label for="metatitle">Meta Title</label>
                                    <input class="form-control <?php $__errorArgs = ['metatitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="metatitle" name="metatitle" type="text" placeholder="Meta Title" value="<?php echo e(old('metatitle', $workshop->metatitle)); ?>">
                                    <?php $__errorArgs = ['metatitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                              </div>
                              <div class="col-md-6 col-12">
                                 <div class="form-group mb-2">
                                    <label for="metakeyword">Meta Keyword</label>
                                    <input class="form-control <?php $__errorArgs = ['metakeyword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="metakeyword" name="metakeyword" type="text" placeholder="Meta Keyword" value="<?php echo e(old('metakeyword', $workshop->metakeywords)); ?>">
                                    <?php $__errorArgs = ['metakeyword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                              </div>
                              <div class="col-md-12 col-12">
                                 <div class="form-group mb-2">
                                    <label for="metadescription">Meta Description</label>
                                    <textarea class="form-control <?php $__errorArgs = ['metadescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="metadescription" name="metadescription" rows="4" placeholder="Meta Description"><?php echo e(old('metadescription', $workshop->metadescription)); ?></textarea>
                                    <?php $__errorArgs = ['metadescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                              </div>
                           </div>
                           <button class="btn btn-success mr-2" type="submit">
                           <i class="ft-check-square mr-1"></i>Update
                           </button>
                           <a href="<?php echo e(URL::previous()); ?>">
                           <button class="btn btn-secondary" type="button">
                           <i class="ft-x mr-1"></i>Back
                           </button>
                           </a>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section id="basic-hidden-label-form-layouts">
         <div class="row match-height">
            <div class="col-lg-12 col-md-12 col-12">
               <div class="card">
                  <div class="card-header alert alert-warning pb-2">
                     <h4 class="card-title">Add Except</h4>
                  </div>
                  <div class="card-content">
                     <div class="card-body">
                        <form method="post" action="<?php echo e(route('workshop.except')); ?>">
                           <?php echo csrf_field(); ?>
                           <input type="hidden" name="workshopid" value="<?php echo e($eid); ?>">
                           <?php $__currentLoopData = $workshop->except; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $except): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="repeatable mb-3">
                              <div class="row">
                                 <div class="col-md-11">
                                    <div class="mb-2">
                                       <input class="form-control" id="except" name="except[]" placeholder="Except" required="" type="text" value="<?php echo e($except->except); ?>">
                                    </div>
                                 </div>
                                 <div class="col-md-1">
                                    <div class="form-check">
                                       <input class="btn btn-danger" id="removeRow" type="button" value="x">
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <div id="newincRow"></div>
                           <div class="row mb-3">
                              <div class="col-sm-12">
                                 <input type="button" id="addincRow" class="btn btn-primary mr-2" value="+ Add Inclusion">
                                 <button class="btn btn-success" type="submit">
                                 <i class="ft-check-square mr-1"></i>Save
                                 </button>
                              </div>
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section id="basic-hidden-label-form-layouts">
         <div class="row match-height">
            <div class="col-lg-12 col-md-12 col-12">
               <div class="card">
                  <div class="card-header alert alert-warning pb-2">
                     <h4 class="card-title">Add Modules</h4>
                  </div>
                  <div class="card-content">
                     <div class="card-body">
                        <form method="post" action="<?php echo e(route('workshop.modules')); ?>">
                           <?php echo csrf_field(); ?>
                           <input type="hidden" name="workshopid" value="<?php echo e($eid); ?>">
                           <?php $__currentLoopData = $workshop->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modules): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="repeatable mb-3">
                              <div class="row">
                                 <div class="col-md-11">
                                    <div class="mb-2">
                                       <label class="form-label col-form-label" for="heading">Heading</label>
                                       <input class="form-control" id="heading" name="heading[]" placeholder="Heading" required="" type="text" value="<?php echo e($modules->question); ?>">
                                    </div>
                                    <div class="mb-2">
                                       <label class="form-label col-form-label" for="comment">Description</label>
                                       <textarea class="form-control summernote" id="comment" name="comment[]" placeholder="Description" required=""><?php echo e($modules->answer); ?></textarea>
                                    </div>
                                 </div>
                                 <div class="col-md-1">
                                    <div class="form-check">
                                       <input class="btn btn-danger mt-4" id="removeRow" type="button" value="x">
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <div id="newccRow"></div>
                           <div class="row mb-3">
                              <div class="col-sm-12">
                                 <input type="button" id="addccRow" class="btn btn-primary mr-2" value="Add Modules">
                                 <button class="btn btn-success" type="submit">
                                 <i class="ft-check-square mr-1"></i>Save
                                 </button>
                              </div>
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section id="basic-hidden-label-form-layouts">
         <div class="row match-height">
            <div class="col-lg-12 col-md-12 col-12">
               <div class="card">
                  <div class="card-header alert alert-warning pb-2">
                     <h4 class="card-title">Add Additional Resources</h4>
                  </div>
                  <div class="card-content">
                     <div class="card-body">
                        <form method="post" action="<?php echo e(route('workshop.resources')); ?>">
                           <?php echo csrf_field(); ?>
                           <input type="hidden" name="workshopid" value="<?php echo e($eid); ?>">
                           <?php $__currentLoopData = $workshop->resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resources): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="repeatable mb-3">
                              <div class="row">
                                 <div class="col-md-11">
                                    <div class="mb-2">
                                       <input class="form-control" id="resource" name="resource[]" placeholder="Resource" required="" type="text" value="<?php echo e($except->resources); ?>">
                                    </div>
                                 </div>
                                 <div class="col-md-1">
                                    <div class="form-check">
                                       <input class="btn btn-danger" id="removeRow" type="button" value="x">
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <div id="newresourceRow"></div>
                           <div class="row mb-3">
                              <div class="col-sm-12">
                                 <input type="button" id="addresourceRow" class="btn btn-primary mr-2" value="+ Add Resources">
                                 <button class="btn btn-success" type="submit">
                                 <i class="ft-check-square mr-1"></i>Save
                                 </button>
                              </div>
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section id="basic-hidden-label-form-layouts">
         <div class="row match-height">
            <div class="col-lg-12 col-md-12 col-12">
               <div class="card">
                  <div class="card-header alert alert-warning pb-2">
                     <h4 class="card-title">Add Testimonial</h4>
                  </div>
                  <div class="card-content">
                     <div class="card-body">
                        <form method="post" action="<?php echo e(route('workshop.testimonial')); ?>">
                           <?php echo csrf_field(); ?>
                           <input type="hidden" name="workshopid" value="<?php echo e($eid); ?>">
                           <?php $__currentLoopData = $workshop->Testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="repeatable mb-3">
                              <div class="row">
                                 <div class="col-md-11">
                                    <div class="mb-2">
                                       <label class="form-label col-form-label" for="name">Name</label>
                                       <input class="form-control" id="name" name="name[]" placeholder="name" required="" type="text" value="<?php echo e($testimonial->name); ?>">
                                    </div>
                                    <div class="mb-2">
                                       <label class="form-label col-form-label" for="review">Review</label>
                                       <textarea class="form-control" id="review" name="review[]" placeholder="Review" required=""><?php echo e($testimonial->review); ?></textarea>
                                    </div>
                                 </div>
                                 <div class="col-md-1">
                                    <div class="form-check">
                                       <input class="btn btn-danger mt-4" id="removeRow" type="button" value="x">
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <div id="newtestimonialRow"></div>
                           <div class="row mb-3">
                              <div class="col-sm-12">
                                 <input type="button" id="addtestimonialRow" class="btn btn-primary mr-2" value="+ Add Testimonial">
                                 <button class="btn btn-success" type="submit">
                                 <i class="ft-check-square mr-1"></i>Save
                                 </button>
                              </div>
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.20/summernote-bs4.min.css"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.20/summernote.min.js"></script>
<script>
   $(document).ready(function() {
       $('.summernote').summernote();
   })
</script>
<script type="text/javascript">
   $("#addincRow").click(function () {
       var html = '';
       html += '<div class="repeatable mb-3"><div class="row"><div class="col-md-11"><div class="mb-2"><input class="form-control" id="except" name="except[]" placeholder="except" required="" type="text"></div></div><div class="col-md-1"><div class="form-check"><input class="btn btn-danger" id="removeRow" type="button" value="x"></div></div></div></div>';
       $('#newincRow').append(html);
   });
   
   $("#addresourceRow").click(function () {
       var html = '';
       html += '<div class="repeatable mb-3"><div class="row"><div class="col-md-11"><div class="mb-2"><input class="form-control" id="resource" name="resource[]" placeholder="resource" required="" type="text"></div></div><div class="col-md-1"><div class="form-check"><input class="btn btn-danger" id="removeRow" type="button" value="x"></div></div></div></div>';
       $('#newresourceRow').append(html);
   });
   $("#addccRow").click(function () {
       var html = '';
       html += '<div class="repeatable mb-3"><div class="row"><div class="col-md-11"><div class="mb-2"><label class="form-label col-form-label" for="heading">Heading</label><input class="form-control" id="heading" name="heading[]" placeholder="Heading" required="" type="text"></div><div class="mb-2"><label class="form-label col-form-label" for="comment">Description.</label><textarea class="form-control summernote" id="comment" name="comment[]" placeholder="" required=""></textarea></div></div><div class="col-md-1"><div class="form-check"><input class="btn btn-danger mt-4" id="removeRow" type="button" value="x"></div></div></div></div>';
       $('#newccRow').append(html);
       $('.summernote').summernote();
   });
   
   
   $("#addtestimonialRow").click(function () {
       var html = '';
       html += '<div class="repeatable mb-3"><div class="row"><div class="col-md-11"><div class="mb-2"><label class="form-label col-form-label" for="name">Name</label><input class="form-control" id="name" name="name[]" placeholder="Name" required="" type="text"></div><div class="mb-2"><label class="form-label col-form-label" for="review">Review</label><textarea class="form-control" id="review" name="review[]" placeholder="" required=""></textarea></div></div><div class="col-md-1"><div class="form-check"><input class="btn btn-danger mt-4" id="removeRow" type="button" value="x"></div></div></div></div>';
       $('#newtestimonialRow').append(html);
       $('.summernote').summernote();
   });
   
   
   
   // remove row
   $(document).on('click', '#removeRow', function () {
       $(this).closest('.repeatable').remove();
   });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\yy\resources\views/back/workshop/edit.blade.php ENDPATH**/ ?>