;
<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-12">
                <div class="content-header">
                    Fix Issue
                </div>
            </div>
        </div>
        <?php if(count($fixissue) > 0): ?>
        <section id="dom">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <form action="<?php echo e(route('deletefixissue')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="card-header">
                                <h4 class="card-title">Fix Issue List</h4>
                                <button class="btn btn-danger float-right">Delete All</button>
                            </div>
                            <div class="card-content">
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="myTable" class="table table-striped table-bordered dom-jQuery-events">
                                            <thead>
                                                <tr>
                                                    <th><input type="checkbox" name="selectAll" id="selectAll"/></th>
                                                    <th>#</th>
                                                    <th>Name</th>
                                                    <th>Device</th>
                                                    <th>Issue</th>
                                                    <th>Date</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $fixissue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><input type="checkbox" class="id_checkbox" name="deleteAll[]" value="<?php echo e($item->id); ?>"/></td>
                                                    <td><?php echo e($key+1); ?></td>
                                                    <td>
                                                        <b>Email: </b><?php echo e($item->email); ?>

                                                        <br>
                                                        <b>Mobile: </b><?php echo e($item->countrycode.' '.$item->mobile); ?>

                                                    </td>
                                                    <td>
                                                        <b>Device: </b><?php echo e($item->device); ?>

                                                        <br>
                                                        <b>Software: </b><?php echo e($item->os); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($item->issue); ?>

                                                    </td>
                                                    <td><?php echo e($item->created_at); ?></td>
                                                    <?php
                                                        $eid = Crypt::encrypt($item->id);
                                                    ?>
                                                    <td>
                                                        <a href="<?php echo e(route('fixissue.destroy',$eid)); ?>" class="btn btn-danger" onclick="return DeleteConfirmation();"><i class="ft-trash-2"></i></a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(document).on('click', '#selectAll', function() {           
        $(".id_checkbox").prop("checked", this.checked);
        $("#select_count").html($("input.id_checkbox:checked").length+" Selected");
    }); 
    $(document).on('click', '.id_checkbox', function() {   
        if ($('.id_checkbox:checked').length == $('.id_checkbox').length) {
          $('#selectAll').prop('checked', true);
        } else {
          $('#selectAll').prop('checked', false);
        }
        $("#select_count").html($("input.id_checkbox:checked").length+" Selected");
    }); 
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/wirelessprinter/public_html/resources/views/back/fixissue/index.blade.php ENDPATH**/ ?>