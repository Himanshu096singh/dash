<div class="app-sidebar menu-fixed" data-background-color="man-of-steel" data-image="../app-assets/img/sidebar-bg/01.jpg" data-scroll-to-active="true">
    <!-- main menu header-->
    <!-- Sidebar Header starts-->
    <div class="sidebar-header">
        <div class="logo clearfix">
            <a class="logo-text float-left" href="<?php echo e(route('dashboard.index')); ?>">
            <div class="logo-img"><img alt="Apex Logo" src="<?php echo e(asset('back/img/logo.png')); ?>"></div>
            <span class="text">APEX</span></a><a class="nav-toggle d-none d-lg-none d-xl-block" href="javascript:;" id="sidebarToggle"><i class="toggle-icon ft-toggle-right" data-toggle="expanded"></i></a><a class="nav-close d-block d-lg-block d-xl-none" href="javascript:;" id="sidebarClose"><i class="ft-x"></i></a>
        </div>
    </div>
    <!-- / main menu header-->
    <!-- main menu content-->
    <div class="sidebar-content main-menu-content">
        <div class="nav-container">
            <ul class="navigation navigation-main" data-menu="menu-navigation" id="main-menu-navigation">
                <li class="has-sub nav-item <?php echo e(Route::is('dashboard.index') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('dashboard.index')); ?>"><i class="ft-home"></i>
                        <span class="menu-item">Dashboard</span>
                    </a>
                </li>
                <li class="has-sub nav-item ">
                    <a href="javascript:void();"><i class="ft-file-text"></i><span class="menu-title">Catgory</span></a>
                    <ul class="menu-content">
                        <li class="<?php echo e(Route::is('category.create') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('category.create')); ?>"><i class="ft-plus-square"></i><span class="menu-item">Add Catgory</span></a>
                        </li>
                        <li class="<?php echo e(Route::is('category.index') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('category.index')); ?>"><i class="ft-eye"></i><span class="menu-item" >View Catgory</span></a>
                        </li>
                    </ul>
                </li>
                <li class="has-sub nav-item">
                    <a href="javascript:void();"><i class="ft-file-text"></i><span class="menu-title">Sub Catgory</span></a>
                    <ul class="menu-content">
                        <li class="<?php echo e(Route::is('subcategory.create') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('subcategory.create')); ?>"><i class="ft-plus-square"></i><span class="menu-item">Add Subcatgory</span></a>
                        </li>
                        <li class="<?php echo e(Route::is('subcategory.index') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('subcategory.index')); ?>"><i class="ft-eye"></i><span class="menu-item" >View Subcatgory</span></a>
                        </li>
                    </ul>
                </li>
                <li class="has-sub nav-item">
                    <a href="javascript:void();"><i class="ft-file-text"></i><span class="menu-title">Blog</span></a>
                    <ul class="menu-content">
                        <li class="<?php echo e(Route::is('blog.create') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('blog.create')); ?>"><i class="ft-plus-square"></i><span class="menu-item">Add Blog</span></a>
                        </li>
                        <li class="<?php echo e(Route::is('blog.index') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('blog.index')); ?>"><i class="ft-eye"></i><span class="menu-item">View Blog</span></a>
                        </li>
                    </ul>
                </li>
                <li class="has-sub nav-item">
                    <a href="javascript:void();"><i class="ft-file-text"></i><span class="menu-title">Product</span></a>
                    <ul class="menu-content">
                        <li class="<?php echo e(Route::is('product.create') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('product.create')); ?>"><i class="ft-plus-square"></i><span class="menu-item">Add Product</span></a>
                        </li>
                        <li class="<?php echo e(Route::is('product.index') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('product.index')); ?>"><i class="ft-eye"></i><span class="menu-item">View Product</span></a>
                        </li>
                    </ul>
                </li>
                <li class="has-sub nav-item">
                    <a href="javascript:void();"><i class="ft-file-text"></i><span class="menu-title">User</span></a>
                    <ul class="menu-content">
                        <li class="<?php echo e(Route::is('user.create') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('user.create')); ?>"><i class="ft-plus-square"></i><span class="menu-item">Add User</span></a>
                        </li>
                        <li class="<?php echo e(Route::is('user.index') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('user.index')); ?>"><i class="ft-eye"></i><span class="menu-item">View User</span></a>
                        </li>
                    </ul>
                </li>
                <li class="has-sub nav-item">
                    <a href="javascript:void();"><i class="ft-file-text"></i><span class="menu-title">Support Faqs</span></a>
                    <ul class="menu-content">
                        <li class="<?php echo e(Route::is('supportfaq.create') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('supportfaq.create')); ?>"><i class="ft-plus-square"></i><span class="menu-item" >Add Supportfaqs</span></a>
                        </li>
                        <li class="<?php echo e(Route::is('supportfaq.index') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('supportfaq.index')); ?>"><i class="ft-eye"></i><span class="menu-item">View Supportfaqs</span></a>
                        </li>
                    </ul>
                </li>
                <li class="has-sub nav-item">
                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="icon-logout"></i><span class="menu-item" >Logout</span></a>
                    <form id="logout-form" class="d-none" action="<?php echo e(route('logout')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                    </form>
                </li>
                
            </ul>
        </div>
    </div>
    <div class="sidebar-background"></div>
</div>
<?php /**PATH C:\xampp\htdocs\admin.laravel\resources\views/layouts/include/sidebar.blade.php ENDPATH**/ ?>