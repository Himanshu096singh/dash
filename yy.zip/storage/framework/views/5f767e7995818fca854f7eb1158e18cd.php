<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-12">
                <div class="content-header">
                    Dashboard
                </div>
            </div>
        </div>
        <section id="dom">
    		<div class="row">
    			<div class="col-12">
    				<div class="card">
    					<div class="card-header"></div>

    				</div>
    			</div>
    		</div>
    	</section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\yy\resources\views/back/home.blade.php ENDPATH**/ ?>