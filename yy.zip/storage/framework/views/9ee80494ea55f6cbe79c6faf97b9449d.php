<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- BEGIN VENDOR CSS-->
    <!-- font icons-->
    
    <!-- END VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/css/bootstrap-extended.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/css/colors.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/css/components.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/css/themes/layout-dark.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('back/css/plugins/switchery.min.css')); ?>">
    <!-- END APEX CSS-->
    <!-- BEGIN Page Level CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('back/css/pages/authentication.css')); ?>">
    <!-- END Page Level CSS-->
    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('back/css/style.css')); ?>">
    <!-- END: Custom CSS-->
</head>
<body>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <script src="<?php echo e(asset('back/vendors/js/vendors.min.js')); ?>"></script>
    <script src="<?php echo e(asset('back/vendors/js/switchery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('back/js/core/app-menu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('back/js/core/app.min.js')); ?>"></script>
    <script src="<?php echo e(asset('back/js/notification-sidebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('back/js/customizer.min.js')); ?>"></script>
    <script src="<?php echo e(asset('back/js/scroll-top.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH /home3/wirelessprinter/connectprintertowifi.com/resources/views/layouts/app.blade.php ENDPATH**/ ?>