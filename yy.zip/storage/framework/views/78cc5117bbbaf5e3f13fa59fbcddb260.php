
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://rawgit.com/LeshikJanz/libraries/master/Bootstrap/baguetteBox.min.css">
<style>
   .tz-gallery .row > div {padding: 2px;}
   .tz-gallery .lightbox img {width: 100%;border-radius: 0;position: relative;}
   .tz-gallery .lightbox:before {position: absolute;top: 50%;left: 50%;margin-top: -13px;margin-left: -13px;opacity: 0;color: #fff;font-size: 26px;font-family: 'Font Awesome 5 Free';content: '\f03e';
   pointer-events: none;z-index: 9000;transition: 0.4s;}
   .tz-gallery .lightbox:after {position: absolute;top: 0;left: 0;width: 100%;height: 100%;opacity: 0;background-color: rgba(237, 71, 101, 0.677);content: '';transition: 0.4s;}
   .tz-gallery .lightbox:hover:after,
   .tz-gallery .lightbox:hover:before {opacity: 1;}
   .baguetteBox-button {background-color: transparent !important;}
   @media(max-width: 768px) {
   body {padding: 0;}
   }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="breadcrumb_section page-title-light background_bg overlay_bg_blue_70" data-img-src="https://bestwebcreator.com/dhyana/demo/assets/images/breadcrumb_bg.jpg">
   <div class="container">
      <div class="row align-items-center">
         <div class="col-sm-12 text-center">
            <div class="page-title">
               <h1>Gallery</h1>
            </div>
            <nav aria-label="breadcrumb">
               <ol class="breadcrumb justify-content-center">
                  <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Gallery</li>
               </ol>
            </nav>
         </div>
      </div>
   </div>
</section>
<section>
   <div class="container">
      <div class="tz-gallery">
         <div class="row">
            <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-12 col-md-4 p-2 ">
               <div class="card p-3 rounded shadow">
                  <a class="lightbox " href="<?php echo e(asset($list->image)); ?>">
                  <img class="rounded" src="<?php echo e(asset($list->image)); ?>" alt="<?php echo e($list->alt); ?>">
                  </a>
                  <div class="mt-2 pl-1">
                     <p><?php echo e($list->caption); ?></p>
                  </div>
               </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </div>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
<script>
   baguetteBox.run('.tz-gallery');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\yy\resources\views/front/gallery.blade.php ENDPATH**/ ?>