<!doctype html>
<html>
<head>
   <meta charset="utf-8">
   <meta http-equiv="x-ua-compatible" content="ie=edge">
   <title></title>
   <meta name="description" content="">
</head>
<body>
    <h1>New Contact Form: </h1>
    <table>
        <tr>
            <th style="text-align:left">Name :</th>
            <td><?php echo e($mailData['name']); ?></td>
        </tr>
        <tr>
            <th style="text-align:left">Email :</th>
            <td><?php echo e($mailData['email']); ?></td>
        </tr>
        <tr>
            <th style="text-align:left">Country :</th>
            <td><?php echo e($mailData['country_selector_code']); ?></td>
        </tr>
        <tr>
            <th style="text-align:left">Phone Number :</th>
            <td><?php echo e($mailData['phone']); ?></td>
        </tr>
        <tr>
            <th style="text-align:left">Subject :</th>
            <td><?php echo e($mailData['subject']); ?></td>
        </tr>
        <tr>
            <th style="text-align:left">Message</th>
            <td><?php echo e($mailData['message']); ?></td>
        </tr>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\yy\resources\views/mail/email.blade.php ENDPATH**/ ?>