
<?php $__env->startSection('content'); ?>
   <section>
      <div class="container">
         <div class="row">
            <div class="head text-center mb-3">
               <h1 class="text-uppercase"><?php echo e($workshop->name); ?></h1>
            </div>
         </div>
         <div class="row">
            <div class="col-md-6 px-1 py-1 secleftimg">
               <img src="<?php echo e(asset($workshop->image)); ?>" class="rounded" width="100%" alt="<?php echo e($workshop->alt); ?>">
            </div>
            <div class="col-md-6 px-1 py-1 secrightimg">
               <div class="row m-0">
                  <div class="col-md-6 px-1 pb-1 pt-0">
                     <img src="<?php echo e(asset($workshop->image2)); ?>" class="rounded" width="100%" alt="<?php echo e($workshop->alt2); ?>">
                  </div>
                  <div class="col-md-6 px-1 pb-1 pt-0">
                     <img src="<?php echo e(asset($workshop->image3)); ?>" class="rounded" width="100%" alt="<?php echo e($workshop->alt3); ?>">
                  </div>
                  <div class="col-md-6 px-1 pt-2">
                     <img src="<?php echo e(asset($workshop->image4)); ?>" class="rounded" width="100%" alt="<?php echo e($workshop->alt4); ?>">
                  </div>
                  <div class="col-md-6 px-1 pt-2">
                     <img src="<?php echo e(asset($workshop->image5)); ?>" class="rounded" width="100%" alt="<?php echo e($workshop->alt5); ?>">
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <section>
      <div class="container">
         <div class="row">
            <div class="col-lg-8">
               <div class="single_classes">
                  <div id="about" class="mb-5 workshop">
                     <h3>About </h3>
                     <hr class="bg-default opacity-100" style="height:2px"/>
                     <div class="classes_detail">
                        <?php echo $workshop->about; ?>

                        <div class="countent_detail_meta">
                           <ul>
                              <li>
                                 <div class="classes_days">
                                    <label>Duration: </label>
                                    <span><?php echo e($workshop->duration); ?></span>
                                 </div>
                              </li>
                              <li>
                                 <div class="classes_time">
                                    <label>No of sessions: </label>
                                    <span><?php echo e($workshop->session); ?> </span>
                                 </div>
                              </li>
                              <li>
                                 <div class="classes_date">
                                    <label>Online Workshop: </label>
                                    <span>$<?php echo e(number_format($workshop->onlineprice, 2)); ?> USD</span>
                                 </div>
                              </li>
                              <li>
                                 <div class="classes_location">
                                    <label>In-Person Workshop: </label>
                                    <span>$<?php echo e(number_format($workshop->inpersonprice, 2)); ?> USD</span>
                                 </div>
                              </li>
                           </ul>
                        </div>
                     </div>
                  </div>
                  <?php if(count($workshop->except)>0): ?>
                  <div id="expect" class="mb-5 workshop expect">
                     <h3>What to expect</h3>
                     <hr class="bg-default opacity-100" style="height:2px"/>
                     <div class="workshop_details">
                        <div class="row">
                           <?php $__currentLoopData = $workshop->except; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="workshoplist">
                              <i class="fa fa-check mx-2 clr-default"> </i>
                              <?php echo e($list->except); ?>

                           </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                     </div>
                  </div>
                  <?php endif; ?>
                  <?php if(count($workshop->modules)>0): ?>
                  <div id="modules" class="mb-5 workshop modules">
                     <h3>Modules</h3>
                     <hr class="bg-default opacity-100" style="height:2px"/>
                     <div class="classes_desc">
                        <div class="faq" id="accordion">
                           <?php $__currentLoopData = $workshop->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="card">
                              <div class="card-header" id="faqHeading-1">
                                 <div class="mb-0">
                                    <h5 class="faq-title mb-0" data-toggle="collapse" data-target="#curriculam-<?php echo e($index+1); ?>" data-aria-expanded="true" data-aria-controls="curriculam-<?php echo e($index+1); ?>">
                                       <?php echo e($list->question); ?>

                                    </h5>
                                 </div>
                              </div>
                              <div id="curriculam-<?php echo e($index+1); ?>" class="collapse" aria-labelledby="faqHeading-<?php echo e($index+1); ?>" data-parent="#accordion">
                                 <div class="card-body">
                                    <?php echo $list->answer; ?>

                                 </div>
                              </div>
                           </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                     </div>
                  </div>
                  <?php endif; ?>
                  <?php if(count($workshop->resources)>0): ?>
                  <div id="expect" class="mb-5 workshop expect">
                     <h3>Additional Resources</h3>
                     <hr class="bg-default opacity-100" style="height:2px"/>
                     <div class="workshop_details">
                        <div class="row">
                           <p>To enhance practical exercises and experiential learning get access</p>
                           <?php $__currentLoopData = $workshop->resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="workshoplist">
                              <i class="fa fa-check mx-2 clr-default"> </i>
                              <?php echo e($list->resources); ?>

                           </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                     </div>
                  </div>
                  <?php endif; ?>
                  <?php if(count($workshop->testimonial)>0): ?>
                  <div id="testimonials" class="mb-5 workshop testimonial">
                     <h3>Our Testimonials</h3>
                     <hr class="bg-default opacity-100" style="height:2px"/>
                     <div class="classes_desc">
                        <div class="" id="testimonial_lists">
                           <?php $__currentLoopData = $workshop->testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="testimonial_style1">
                              <img class="img-fluid open-quotes" src="https://i.imgur.com/Hp91vdT.png" width="20" height="20" style="background: #cf3e5f;padding: 2px;">
                              <div class="testimonial_box p-3" >
                                 <div class="testi_desc mb-4">
                                    <img class="img-fluid open-quotes" src="https://i.imgur.com/Hp91vdT.png" width="20" height="20">
                                    <p class="p-1"><?php echo e($list->review); ?></p>
                                 </div>
                                 <div class="testi_meta d-flex justify-content-center">
                                    <div class="testi_user text-left align-self-center">
                                       <h5 class=" h6 mb-0 ">- <?php echo e($list->name); ?></h5>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                     </div>
                  </div>
                  <?php endif; ?>    
               </div>
            </div>
            <div class="col-lg-4 pt-3 pt-lg-0">
               <div class="course_sidebar">
                  <div class="side_info">
                     <h3 class="text-center">Overview</h3>
                     <div class="courseinfolist">
                        <div style="overflow-x:auto;" class="wtable pt20">
                           <table class="table table-borderless workshopsideinfo" style="font-size:14px;">
                              <tr>
                                 <td>
                                    <span class="font-weight-bold">Duration: </span> <?php echo e($workshop->duration); ?>

                                 </td>
                              </tr>
                              <tr>
                                 <td>
                                    <span class="font-weight-bold">Session: </span> <?php echo e($workshop->session); ?>

                                 </td>
                              </tr>
                              <tr>
                                 <td>
                                    <span class="font-weight-bold">Online Workshop: </span> $<?php echo e(number_format($workshop->onlineprice, 2)); ?> USD
                                 </td>
                              </tr>
                              <tr>
                                 <td>
                                    <span class="font-weight-bold">In-Person Workshop:  </span> $<?php echo e(number_format($workshop->inpersonprice, 2)); ?> USD
                                 </td>
                              </tr>
                           </table>
                        </div>
                        <div class="action_btn d-flex justify-content-between">
                           <a href="" class="btn btn-default d-inline-block m-1 mb-3 px-2 font-weight-normal" style="width:150px"> Book Now </a>
                           <a class="btn btn-default d-inline-block m-1 mb-3 px-2 font-weight-normal" style="width:150px" data-toggle="modal" data-target="#enquiryFormWorkshop"> Enquiry Now </a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <?php echo $__env->make('front.include.workshopEnquiryModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\yy\resources\views/front/workshop.blade.php ENDPATH**/ ?>