<?php $__env->startSection('content'); ?>
<!-- BEGIN : Main Content-->
<div class="main-content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-12">
                <div class="content-header">
                    Enquiry
                </div>
            </div>
        </div>
        <section id="bordered-table">
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header d-flex justify-content-between">
                    <h4 class="card-title"><?php echo e($enquiry->name); ?>'s Enquiry : 
                      <?php if($enquiry->type==0): ?>
                      <span class="badge badge-info">Course</span>
                  <?php else: ?>
                      <span class="badge badge-success">Workshop</span>
                  <?php endif; ?></h4>
                    <h5 class="badge badge-danger"> Date: <?php echo e($enquiry->created_at->format('M, d Y')); ?> </h5>
                  </div>
                  <div class="card-content">
                    <div class="card-body">
                      <div class="table-responsive">
                        <table class="table table-bordered">
                           <tbody>
                                <tr>
                                    <th scope="row">Name</th>
                                    <td><?php echo e($enquiry->name); ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Email</th>
                                    <td><?php echo e($enquiry->email); ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Country</th>
                                    <td><?php echo e($enquiry->country); ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Phone No.</th>
                                    <td><?php echo e($enquiry->phone); ?></td>
                                </tr>
                                <tr>
                                    <th scope="row"><?php echo e($enquiry->type == 0 ? 'Course' : 'Workshop'); ?></th>
                                    <td><?php echo e($enquiry->course); ?></td>
                                </tr>
                                <tr>

                                    <th scope="row">Gender</th>
                                    <td><?php echo e($enquiry->gender); ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Room Type</th>
                                    <td><?php echo e($enquiry->room); ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Message</th>
                                    <td><?php echo e($enquiry->message); ?></td>
                                </tr>
                            
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\yy\resources\views/back/enquiry/show.blade.php ENDPATH**/ ?>