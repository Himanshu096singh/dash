<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-12">
                <div class="content-header">
                    Workshop
                </div>
            </div>
        </div>
        <section id="dom">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Workshop List</h4>
                            <a href="<?php echo e(route('workshop.create')); ?>" class="btn gradient-purple-bliss shadow-z-1-hover float-right"><i class="ft-plus-square"></i> Add New Record</a>
                        </div>
                        <div class="card-content">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="myTable" class="table table-striped table-bordered dom-jQuery-events">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Name</th>
                                                <th>Image</th>
                                                <th>Duration</th>
                                                <th>Session</th>
                                                <th>Date</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $workshop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($key+1); ?></td>
                                                <td>
                                                    <?php echo e($item->name); ?>

                                                <td>
                                                    <img src="<?php echo e(asset($item->image)); ?>" alt="<?php echo e($item->image); ?>" width="100">
                                                </td>
                                                <td>
                                                    <?php echo e($item->duration); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($item->session); ?>

                                                </td>
                                                <td><?php echo e($item->created_at); ?></td>
                                                <?php
                                                    $eid = Crypt::encrypt($item->id);
                                                ?>
                                                <td class="inlinebtn">
                                                    <a href="<?php echo e(route('workshop.edit', $eid)); ?>" class="btn btn-info btn ml-1"><i class="ft-edit"></i></a>
                                                    <?php if(Auth::check() && Auth::user()->role_id == 1): ?>
                                                    <form action="<?php echo e(route('workshop.destroy',$eid)); ?>" method="post" class="ml-1">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button class="btn btn-danger" type="submit" onclick="return DeleteConfirmation();"><i class="ft-trash-2"></i></button>
                                                    </form>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\yy\resources\views/back/workshop/index.blade.php ENDPATH**/ ?>