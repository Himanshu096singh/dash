<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="<?php echo e(asset($setting->fevicon)); ?>">
    <?php if(isset($meta)): ?>
    <title><?php echo e($meta['metatitle']); ?></title>
    <meta name="description" content="<?php echo e($meta['metadescription']); ?>">
    <meta name="keywords" content="<?php echo e($meta['metakeywords']); ?>">
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="website" />
    <meta property="og:site_name" content="<?php echo e($setting->name); ?>" />
    <meta property="og:title" content="<?php echo e($meta['metatitle']); ?>" />
    <meta property="og:description" content="<?php echo e($meta['metadescription']); ?>" />
    <meta property="og:url" content="<?php echo e(url()->full()); ?>" />
    <meta property="og:image" content="<?php echo e(url('public/'.$meta['image'])); ?>" />
    <meta property="og:image:type" content="image/jpeg" />
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="<?php echo e($meta['metatitle']); ?>">
    <meta name="twitter:description" content="<?php echo e($meta['metadescription']); ?>">
    <meta name="twitter:image" content="<?php echo e(url('public/'.$meta['image'])); ?>">
    <meta name="twitter:site" content="<?php echo e($setting->name); ?>">
    <?php else: ?>
    <title><?php echo e($setting->name); ?></title>
    <meta name="description" content="<?php echo e($setting->name); ?>" />
    <meta name="keywords" content="<?php echo e($setting->name); ?>" />
    <meta property="og:title" content="<?php echo e($setting->name); ?>" />
    <meta property="og:type" content="Website" />
    <meta property="og:url" content="<?php echo e(url()->full()); ?>" />
    <meta property="og:image" content="<?php echo e(asset($setting->logo)); ?>" />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:description" content="<?php echo e($setting->name); ?>" />
    <meta name="twitter:title" content="<?php echo e($setting->name); ?>">
    <meta name="twitter:image" content="<?php echo e(asset($setting->logo)); ?>">
    <meta name="twitter:site" content="<?php echo e($setting->name); ?>">
    <?php endif; ?>

    <?php if(isset($meta) && isset($meta['index']) && $meta['index']=='no'): ?>
        <meta name="robots" content="noindex, nofollow" />
        <meta name="googlebot" content="noindex, nofollow" />
        <meta name="bingbot" content="noindex, nofollow" />
    <?php else: ?>
        <meta name="robots" content="<?php echo e($setting->robots == 1 ? 'index, follow' : 'noindex, nofollow'); ?>" />
        <meta name="googlebot" content="<?php echo e($setting->robots == 1 ? 'index, follow' : 'noindex, nofollow'); ?>" />
        <meta name="bingbot" content="<?php echo e($setting->robots == 1 ? 'index, follow' : 'noindex, nofollow'); ?>" />
    <?php endif; ?>


    <link rel="canonical" href="<?php echo e(url()->current()); ?>" />
    <link rel="alternate" href="<?php echo e(url()->current()); ?>" hreflang="x-default" />

    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.7.0/css/all.min.css" />
     
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.css')); ?>">	
    
   
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/country.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php $__env->startSection('css'); ?>
    <?php echo $__env->yieldSection(); ?>
    <?php echo $__env->make('front.include.schema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $code->header; ?>

</head>

<body>
    
    <header class="header_wrap dark_skin main_menu_uppercase main_menu_weight_600 menu_style1">
        <div class="container s">
            <nav class="navbar navbar-expand-lg"> 
                <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                    <img class="logo_light" src="<?php echo e(asset($setting->logo)); ?>" alt="<?php echo e($setting->logoalt); ?>" width="110px">
                    <img class="logo_dark" src="<?php echo e(asset($setting->logo)); ?>" alt="<?php echo e($setting->logoalt); ?>" width="110px">
                    <img class="logo_default" src="<?php echo e(asset($setting->logo)); ?>" alt="<?php echo e($setting->logoalt); ?>" width="110px">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="ion-android-menu"></span> </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
                    <ul class="navbar-nav">
                        <li>
                            <a class="dropdown-item nav-link active nav_item"  href="<?php echo e(route('home')); ?>" >Home</a>
                        </li>
                        <li class="dropdown">
                            <a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown">Yoga Courses</a>
                            <div class="dropdown-menu">
                                <ul> 
                                    <?php $__currentLoopData = $courselist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a class="dropdown-item nav-link nav_item" href="<?php echo e(url($list->slug)); ?>"><?php echo e($list->name); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </li>
                        <li><a class="dropdown-item nav-link nav_item dropdown-toggler" href="#">Workshop</a>
                            <div class="dropdown-menu">
                                <ul> 
                                    <?php $__currentLoopData = $workshoplist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a class="dropdown-item nav-link nav_item" href="<?php echo e(url($list->slug)); ?>"><?php echo e($list->name); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </li>
                        <li><a class="dropdown-item nav-link nav_item" href="<?php echo e(route('blog')); ?>">Blog</a></li> 
                        <li><a class="dropdown-item nav-link nav_item dropdown-toggler" href="#">About</a>
                            <div class="dropdown-menu">
                                <ul> 
                                    <li><a class="dropdown-item nav-link nav_item" href="<?php echo e(route('about')); ?>">About Us</a></li> 
                                    <li><a class="dropdown-item nav-link nav_item" href="<?php echo e(route('testimonial')); ?>">Testimonials</a></li> 
                                </ul>
                            </div>
                        </li>
                        <li><a class="dropdown-item nav-link nav_item" href="<?php echo e(route('contact')); ?>">Contct Us</a></li>
                    </ul>
                </div>
            </nav>
        </div>
    </header>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('front.include.courseEnquiryModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <footer class="footer_dark background_bg" >
        <div class="top_footer">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-sm-7">
                        <div class="footer_logo">
                            <a href="<?php echo e(route('home')); ?>"><img alt="<?php echo e($setting->alt); ?>" src="<?php echo e(asset($setting->logo)); ?>"></a>
                        </div>
                        <div class="footer_desc">
                            <p><?php echo e($setting->disclaimer); ?></p>
                        </div>
                    </div>
                    <div class="col-lg-2 col-sm-5">
                        <h5 class="widget_title3">Quick Links</h5>
                        <ul class="list_none widget_links links_style2">
                            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
                            <li><a href="<?php echo e(route('blog')); ?>">Blog</a></li>
                            <li><a href="<?php echo e(route('gallery')); ?>">Gallery</a></li>
                            <li><a href="<?php echo e(route('testimonial')); ?>">Testimonials</a></li>
                            <li><a href="<?php echo e(route('contact')); ?>">Contact Us</a></li>
                         </ul>
                    </div>
                    <div class="col-lg-3 col-md-7">
                        <h5 class="widget_title3">Our Course</h5>
                        <ul class="list_none widget_links links_style2">
                            <?php $__currentLoopData = $courselist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(url($list->slug)); ?>"><?php echo e($list->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-md-5">
                        <h5 class="widget_title3">Get in Touch</h5>
                        <div class="footer_desc">
                            <ul class="contact_info list_none">
                                <li>
                                    <span class="fa fa-map-marker-alt "></span>
                                    <address><?php echo e($setting->address); ?></address>
                                </li>
                                <li>
                                    <span class="fa fa-mobile-alt"></span>
                                    <a href="tel:<?php echo e($setting->usmobile); ?>"><?php echo e($setting->usmobile); ?></a>
                                </li>
                                <li>
                                    <span class="fa fa-envelope"></span>
                                    <a href="mailto:<?php echo e($setting->email); ?>"><?php echo e($setting->email); ?></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12">
                    <div class="bottom_footer border_top_transparent">
                        <div class="row">
                            <div class="col-md-7">
                                <p class="copyright m-md-0 text-md-left">Copyright © <?php echo e(Date('Y')); ?> - <a href="<?php echo e(route('home')); ?>" class="text_default">Heart Of Yoga</a></p>
                            </div>
                            <div class="col-md-5">
                                <ul class="list_none footer_link text-center text-md-right">
                                    <?php $__currentLoopData = $staticpage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(url($list->slug)); ?>"><?php echo e($list->name); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <a href="#" class="scrollup" style="display: none;"><i class="fa fa-angle-up"></i></a> 

    <script src="<?php echo e(asset('assets/js/jquery-1.12.4.min.js')); ?>"></script> 
    <script src="<?php echo e(asset('assets/js/jquery-ui.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/bootstrap/js/bootstrap.min.js')); ?>"></script> 
    <script src="<?php echo e(asset('assets/js/magnific-popup.min.js')); ?>"></script> 
    <script src="<?php echo e(asset('assets/js/waypoints.min.js')); ?>"></script> 
    <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/country.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/form.js')); ?>"></script>
    <?php $__env->startSection('js'); ?>
    <?php echo $__env->yieldSection(); ?>
     <?php echo $code->footer; ?>

    <?php if(!Route::is('support')): ?>
    <?php echo $code->tawkto; ?>

    <?php endif; ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\yy\resources\views/layouts/front.blade.php ENDPATH**/ ?>