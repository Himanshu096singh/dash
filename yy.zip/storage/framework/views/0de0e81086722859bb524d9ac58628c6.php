<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="breadcrumb_section page-title-light background_bg overlay_bg_blue_70" data-img-src="https://bestwebcreator.com/dhyana/demo/assets/images/breadcrumb_bg.jpg">
        <div class="container">
        <div class="row align-items-center">
            <div class="col-sm-12 text-center">
                <div class="page-title">
                    <h1><?php echo e($page->name); ?></h1>
                </div>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($page->name); ?></li>
                    </ol>
                </nav>
            </div>
        </div>
        </div>
    </section>
    <section style="padding:80px 0px 40px">
        <div class="container ">
            <div class="row ">
                <div class="col-md-12">
                    <h2 class="text-uppercase mb-5" style="font-weight:600;letter-spacing:1.2px;"><?php echo e($page->name); ?></h2>
                    <div class="desc">
                        <?php echo $page->description; ?>

                    </div>
                </div>
            </div>
        </div>
       </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\yy\resources\views/front/staticpage.blade.php ENDPATH**/ ?>