
<?php $__env->startSection('content'); ?>
<!-- BEGIN : Main Content-->
<div class="main-content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-12">
                <div class="content-header">
                    Media
                </div>
            </div>
        </div>
        <section id="basic-hidden-label-form-layouts">
            <div class="row match-height">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Add Media</h4>
                        </div>
                        <div class="card-content">
                            <div class="card-body">
                                <form method="post" action="<?php echo e(route('media.store')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-row">
                                        <div class="col-md-6 col-12">
                                            <div class="form-group mb-2">
                                                <label for="name">Name</label>
                                                <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" type="text" placeholder="Name" value="<?php echo e(old('name')); ?>">
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group mb-2">
                                                <label for="image">Image</label>
                                                <input class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="image" name="image[]" type="file"  value="<?php echo e(old('image')); ?>" multiple>
                                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <button class="btn btn-primary mr-2" type="submit">
                                        <i class="ft-check-square mr-1"></i>Save
                                    </button>
                                    <a href="<?php echo e(URL::previous()); ?>">
                                        <button class="btn btn-secondary" type="button">
                                            <i class="ft-x mr-1"></i>Back
                                        </button>
                                    </a>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php if(count($media) > 0): ?>
        <section id="basic-hidden-label-form-layouts">
            <div class="row match-height my-5">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Media List</h4>
                            <button class="btn btn-danger float-right" type="button" onclick="DeleteAll();">Delete All</button>
                        </div>
                        <div class="card-content">
                            <div class="card-body">
                                <table id="myTable" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th><input type="checkbox" name="selectAll" id="selectAll"/></th>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Image</th>
                                            <th>Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><input type="checkbox" id="id_checkbox<?php echo e($key); ?>" class="id_checkbox items" name="deleteAll[]" value="<?php echo e($item->id); ?>"/></td>
                                            <td><?php echo e($key+1); ?></td>
                                            <td><?php echo e($item->name); ?></td>
                                            <td>
                                                <img src="<?php echo e(asset($item->image)); ?>" alt="<?php echo e($item->image); ?>" width="100">
                                            </td>
                                            <td><?php echo e($item->created_at); ?></td>
                                            <?php
                                                $eid = Crypt::encrypt($item->id);
                                            ?>
                                            <td>
                                                <a class="btn btn-warning" onclick="setClipboard('<?php echo e(asset($item->image)); ?>')">Copy URL</a>
                                                <form action="<?php echo e(route('media.destroy',$eid)); ?>" method="post" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <a class="btn btn-danger" type="submit" onclick="return DeleteConfirmation();"><i class="ft-trash-2"></i></a>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    function setClipboard(value) {
        var tempInput = document.createElement("input");
        tempInput.style = "position: absolute; left: -1000px; top: -1000px";
        tempInput.value = value;
        document.body.appendChild(tempInput);
        tempInput.select();
        document.execCommand("copy");
        document.body.removeChild(tempInput);
    }
    $(document).on('click', '#selectAll', function() {           
        $(".id_checkbox").prop("checked", this.checked);
        $("#select_count").html($("input.id_checkbox:checked").length+" Selected");
    }); 
    $(document).on('click', '.id_checkbox', function() {   
        if ($('.id_checkbox:checked').length == $('.id_checkbox').length) {
          $('#selectAll').prop('checked', true);
        } else {
          $('#selectAll').prop('checked', false);
        }
        $("#select_count").html($("input.id_checkbox:checked").length+" Selected");
    });
    
    function DeleteAll() {
        let checkedValue = document.querySelectorAll('.items:checked');
         //console.log(checkedValue);
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        let arrayValue = [];
        
        for (let i = 0; i < checkedValue.length; i++) {
            arrayValue.push(checkedValue[i].value);
        }
        $.ajax({
            url:"<?php echo e(route('media.deletemultiple')); ?>",
            type:'post',
            data:{
                id:arrayValue 
            },
            success:function(res)
            {
                if(res==1){
                    window.location.reload();
                }else{
                    console.log(res);
                }
            }
        });
    } 
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/wirelessprinter/public_html/resources/views/back/media/index.blade.php ENDPATH**/ ?>