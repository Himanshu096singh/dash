<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/binouze/lightboxjs/src/lightboxjs.min.css" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="breadcrumb_section page-title-light background_bg overlay_bg_blue_70" data-img-src="https://bestwebcreator.com/dhyana/demo/assets/images/breadcrumb_bg.jpg">
    <div class="container">
       <div class="row align-items-center">
          <div class="col-sm-12 text-center headertitlebox">
             <div class="page-title">
                <h1>Testimonial</h1>
             </div>
             <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center">
                   <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                   <li class="breadcrumb-item active" aria-current="page">Testimonial</li>
                </ol>
             </nav>
          </div>
       </div>
    </div>
 </section>
 <!-- END SECTION BREADCRUMB -->
 <section class="small_pb">
	<div class="container">
    	<div class="row">
        	<div class="col-md-12 text-center">
                <div class="heading_s2">
                    <h3>What Our Students Say About Us</h3>
                    <div class="m-auto title_icon"><i class="flaticon-lotus"></i></div> 
                </div>
                
            </div>
        </div>

        <?php if(count($video)>0): ?>
            <div class="row mb-5">
                <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="video-testimonial-block">
                            <div class="lightboxjs-link" data-width="1000" data-height="600" data-url="https://www.youtube.com/embed/<?php echo e($list->youtube); ?>">
                                <div class="video">
                                    <div class="video-thumbnail"><img src="https://img.youtube.com/vi/<?php echo e($list->youtube); ?>/mqdefault.jpg" alt="video testimonial" class="img-fluid"></div>
                                </div>
                                <a href="#" class="video-play"></a>
                            </div>
                        </div>
                        <div class="testi_meta d-flex justify-content-start">
                            <div class="testimonial_img mr-3">
                                <img class="rounded-circle" src="<?php echo e(asset($list->image)); ?>" alt="<?php echo e($list->name); ?>" style="width:60px">
                            </div>
                            <div class="testi_user text-left align-self-center">
                                <h5 class=" h6 mb-0 "><?php echo e($list->name); ?></h5>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <div class="row mt-5">
        	<div class="col-12 animation animated fadeInUp" data-animation="fadeInUp" data-animation-delay="0.2s" style="animation-delay: 0.2s; opacity: 1;">
            	<?php $__currentLoopData = $testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="testimonial_style1">
                        <img class="img-fluid open-quotes" src="https://i.imgur.com/Hp91vdT.png" width="20" height="20" style="background: #cf3e5f;padding: 2px;">
                        <div class="testimonial_box p-5" >
                            
                            <div class="testi_desc mb-4">
                                <img class="img-fluid open-quotes" src="https://i.imgur.com/Hp91vdT.png" width="20" height="20">
                                <p class="p-2"><?php echo e($list->review); ?></p>
                            </div>
                            <div class="testi_meta d-flex justify-content-start">
                                <div class="testimonial_img mr-3">
                                    <img src="<?php echo e(asset($list->image)); ?>" alt="<?php echo e($list->name); ?>" style="width:60px" >
                                </div>
                                <div class="testi_user text-left align-self-center">
                                    <h5 class=" h6 mb-0 "><?php echo e($list->name); ?></h5>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/gh/binouze/lightboxjs/src/lightboxjs.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\yy\resources\views/front/testimonial.blade.php ENDPATH**/ ?>