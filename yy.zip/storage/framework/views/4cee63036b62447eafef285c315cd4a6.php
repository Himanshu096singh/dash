<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-12">
                <div class="content-header">
                    Staticpage
                </div>
            </div>
        </div>
        <section id="dom">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Staticpage List</h4>
                            <a href="<?php echo e(route('staticpage.create')); ?>" class="btn gradient-purple-bliss shadow-z-1-hover float-right"><i class="ft-plus-square"></i> Add New Record</a>
                        </div>
                        <div class="card-content">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="myTable" class="table table-striped table-bordered dom-jQuery-events">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Page Detail</th>
                                                <th>Status</th>
                                                <th>Date</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $staticpage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($key+1); ?></td>
                                                <td>
                                                    <b>Name: </b><?php echo e($item->name); ?>

                                                    <br/>
                                                    <b>Slug: </b><?php echo e($item->slug); ?>

                                                </td>
                                                <td>
                                                    <?php if($item->status == 1): ?>
                                                        <span class="badge badge-success">Active</span>
                                                    <?php else: ?>
                                                        <span class="badge badge-danger">Inactive</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($item->created_at); ?></td>
                                                <?php
                                                    $eid = Crypt::encrypt($item->id);
                                                ?>
                                                <td>
                                                    <?php if($item->status == 1): ?>
                                                        <a href="<?php echo e(url($item->slug)); ?>" target="_blank" class="btn btn-warning btn"><i class="ft-eye"></i></a>
                                                    <?php endif; ?>
                                                    <a href="<?php echo e(route('staticpage.edit', $eid)); ?>" class="btn btn-info btn"><i class="ft-edit"></i></a>
                                                    <form action="<?php echo e(route('staticpage.destroy',$eid)); ?>" method="post" class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button class="btn btn-danger" type="submit" onclick="return DeleteConfirmation();"><i class="ft-trash-2"></i></button>
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\yy\resources\views/back/staticpage/index.blade.php ENDPATH**/ ?>