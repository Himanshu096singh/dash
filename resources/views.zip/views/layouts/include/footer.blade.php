<footer class="footer undefined undefined">
    <p class="clearfix text-muted m-0"><span>Copyright &copy; {{ date('Y') }} &nbsp;</span><a href="{{ config('app.url') }}" id="pixinventLink" target="_blank">{{ config('app.name') }}</a><span class="d-none d-sm-inline-block">, All rights reserved.</span></p>
</footer>
<button class="btn btn-primary scroll-top" type="button"><i class="ft-arrow-up"></i></button>
