<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Code;
use Illuminate\Support\Facades\Validator;

class CodeController extends Controller
{
    public function create()
    {
        $code = Code::first();
        return view('back.code.create', compact('code'));
    }

    public function store(Request $request)
    {
        // $validator = Validator::make($request->all(), [
        //     'header'          =>    'required',
        //     'footer'          =>    'required',
        //     'tawktourl'       =>    'required',
        //     'tawkto'          =>    'required',
        // ]);
        // if($validator->fails()){
        //     return redirect()->back()
        //     ->withErrors($validator)->withInput();
        // }

        $codeexist = Code::first();
        if($codeexist->id != null){
            $setting            =       Code::findOrFail(1);
        }else{
            $setting            =       new Code;
        }

        $setting->header              =       $request->header;
        $setting->footer              =       $request->footer;
        $setting->tawktourl           =       $request->tawktourl;
        $setting->tawkto              =       $request->tawkto;
        $setting->save();
        return redirect()->back()->with('success','Successfully Updated !');
    }
    
    public function customcssjs()
    {
        $code = Code::first();
        return view('back.code.create', compact('code'));
    }
}
