<footer class="footer undefined undefined">
    <p class="clearfix text-muted m-0"><span>Copyright &copy; <?php echo e(date('Y')); ?> &nbsp;</span><a href="<?php echo e(config('app.url')); ?>" id="pixinventLink" target="_blank"><?php echo e(config('app.name')); ?></a><span class="d-none d-sm-inline-block">, All rights reserved.</span></p>
</footer>
<button class="btn btn-primary scroll-top" type="button"><i class="ft-arrow-up"></i></button>
<?php /**PATH /home3/wirelessprinter/connectprintertowifi.com/resources/views/layouts/include/footer.blade.php ENDPATH**/ ?>