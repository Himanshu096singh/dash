
<?php $__env->startSection('css'); ?>
<style>
   div.tab-pane img{max-width: 100% !important;height: auto !important;}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
   <div class="col-md-9">
      <div class="main-content p-3 p-md-5 pb-md-2 m-md-1">
         <div class="row mb-3">
            <div class="col-md-4"> 
               <img src="<?php echo e(asset($product->image)); ?>" alt="<?php echo e($product->alt); ?>" class="img-fluid rounded-2 pb-3">
            </div>
            <div class="col-md-8">
               <div class="blog_breadcrumb">
                  <ul class="list-inline" vocab="http://schema.org/" typeof="BreadcrumbList">
                     <li class="list-inline-item text-dark" property="itemListElement" typeof="ListItem">
                        <a href="<?php echo e(route('home')); ?>" class="text-decoration-none"  property="item" typeof="WebPage"> <span property="name">Home</span> </a>
                     </li>
                     <li class="list-inline-item" property="itemListElement" typeof="ListItem">
                        <a href="<?php echo e(url($category->slug)); ?>" class="text-decoration-none"  property="item" typeof="WebPage"> <span property="name"><?php echo e($category->name); ?></span> </a>
                     </li>
                  </ul>
               </div>
               <h1 class="h3 text-dark"><?php echo e($product->name); ?></h1>
               <div class="product-review pb-3">
                  <i class="fas fa-star color-<?php echo e($category->slug); ?>"></i>
                  <i class="fas fa-star color-<?php echo e($category->slug); ?>"></i>
                  <i class="fas fa-star color-<?php echo e($category->slug); ?>"></i>
                  <i class="fas fa-star color-<?php echo e($category->slug); ?>"></i>
                  <i class="fas fa-star color-<?php echo e($category->slug); ?>"></i>
                  <span class="ms-3 fs-13"> 4.5 / 18 Rating</span>
               </div>
               <div class="row brand_blog_info">
                  <div class="col-6 "><a href="<?php echo e(route('support')); ?>" class="btn btn-success "><span class="text-light fs-12">Support Team</span></a></div>
                  <div class="col-6"><a id="" class="btn btn-info openMyForm222"><span class="text-light">Fix Your Issue</span></a></div>
               </div>
            </div>
         </div>
         <div class="product_desc">
            <nav>
               <div class="nav nav-tabs" id="nav-tab" role="tablist">
                  <button class="nav-link color-<?php echo e($category->slug); ?> active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#description" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Description </button>
                  <button class="nav-link color-<?php echo e($category->slug); ?>" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#how-to-setup" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">How To Setup</button>
               </div>
            </nav>
            <div class="tab-content py-3 px-2" id="nav-tabContent">
               <div class="tab-pane fade show active" id="description" role="tabpanel" aria-labelledby="nav-home-tab">
                  <?php echo $product->description; ?>

               </div>
               <div class="tab-pane fade" id="how-to-setup" role="tabpanel" aria-labelledby="nav-profile-tab">
                  <?php echo $product->setup; ?>

               </div>
            </div>
            <?php if(count($product->faqs ) > 0): ?>
            <!-- Product FAQs Starts ------------------------->
            <div id="question-answer" class="brand_faqs">
               <h2> Frequently Asked Questions </h2>
               <hr>
               <div>
                  <?php $__currentLoopData = $product->faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="brand_faqs_qa bg-white">
                     <div class="faqs_question mb-3">
                        <h6><span class="badge bg-<?php echo e($category->slug); ?>"> Question </span></h6>
                        <h3><?php echo e($item->question); ?></h3>
                     </div>
                     <div class="faqs_answer">
                        <?php echo $item->answer; ?>

                     </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
            </div>
            <!-- Product FAQs Ends ------------------------->
            <?php endif; ?>
         </div>
      </div>
   </div>
   <div class="col-md-3">
      <?php echo $__env->make('front.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/wirelessprinter/public_html/resources/views/front/productdetail.blade.php ENDPATH**/ ?>