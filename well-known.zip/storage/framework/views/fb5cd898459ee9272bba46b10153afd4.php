<div class="sidebar p-md-5 p-3 ps-md-0">
    <div class="side_advertisment mb-4 text-center">
        <a href="<?php echo e(route('support')); ?>" title="Download Printer Driver">
            <img src="<?php echo e(asset('assets/images/download-driver.png')); ?>" alt="download printer driver" class="img-fluid">
        </a>
    </div>
    
    <div class="recent_block">
      <div class="sidebar_head mb-4">
        <h3 class="h5 text-center"> Top Blogs</h3>
      </div>
        <ul class="list-unstyled">
            <?php $__currentLoopData = $latestblog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li> 
                  <a class="text-decoration-none" href="<?php echo e(url($list->category->slug.'/'.$list->slug)); ?>" title="<?php echo e($list->name); ?>">  <?php echo e($list->name); ?>  </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ul>
    </div>

    <div class="brand_block">
      <div class="sidebar_head mb-4">
        <h3 class="h5 text-center"> Top Brands</h3>
      </div>
      <ul class="list-unstyled list-inline">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-inline-item"> 
                  <a class="text-decoration-none fs-6 badge rounded-pill bg-<?php echo e($list->slug); ?>" href="<?php echo e(url($list->slug)); ?>">  <?php echo e($list->name); ?> </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>

    <div class="disclaimer_block">
      <hr>
      <p class="fs-14"><?php echo e($setting->disclaimer); ?></p>
    </div>

</div><?php /**PATH /home3/wirelessprinter/bluetoothprintersetup.com/resources/views/front/include/sidebar.blade.php ENDPATH**/ ?>