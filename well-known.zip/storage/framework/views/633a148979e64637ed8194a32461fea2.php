<?php echo '<?xml version="1.0" encoding="UTF-8"?>'; ?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc><?php echo e(route('home')); ?></loc>
        <lastmod><?php echo e($blog[0]->updated_at->tz('UTC')->toAtomString()); ?></lastmod>
        <changefreq>weekly</changefreq>
        <priority>1.0</priority>
    </url>
    <url>
        <loc>https://wirelessprinter.online/support</loc>
        <lastmod>2023-06-20T07:08:20+00:00</lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.80</priority>
    </url>
    
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <url>
            <loc><?php echo e(url($list->slug)); ?></loc>
            <lastmod><?php echo e($list->updated_at->tz('UTC')->toAtomString()); ?></lastmod>
            <changefreq>weekly</changefreq>
            <priority>0.80</priority>
        </url>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $list->subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sublist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <url>
                <loc><?php echo e(url($list->slug.'/'.$sublist->slug)); ?></loc>
                <lastmod><?php echo e($list->updated_at->tz('UTC')->toAtomString()); ?></lastmod>
                <changefreq>weekly</changefreq>
                <priority>0.80</priority>
            </url>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
   <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <url>
            <loc><?php echo e(url( $list->category->slug.'/'.$list->slug)); ?></loc>
            <lastmod><?php echo e($list->updated_at->tz('UTC')->toAtomString()); ?></lastmod>
            <changefreq>weekly</changefreq>
            <priority>0.80</priority>
        </url>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <url>
            <loc><?php echo e(url( $list->category->slug.'/'.$list->slug)); ?></loc>
            <lastmod><?php echo e($list->updated_at->tz('UTC')->toAtomString()); ?></lastmod>
            <changefreq>weekly</changefreq>
            <priority>0.80</priority>
        </url>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if( count($list->error)>0 ): ?>
        <url>
            <loc><?php echo e(url($list->slug.'/errors')); ?></loc>
            <lastmod><?php echo e($list->updated_at->tz('UTC')->toAtomString()); ?></lastmod>
            <changefreq>weekly</changefreq>
            <priority>0.80</priority>
        </url>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
        
    <?php $__currentLoopData = $staticpage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <url>
            <loc><?php echo e(url( $list->slug)); ?></loc>
            <lastmod><?php echo e($list->updated_at->tz('UTC')->toAtomString()); ?></lastmod>
            <changefreq>weekly</changefreq>
            <priority>0.65</priority>
        </url>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</urlset><?php /**PATH /home3/wirelessprinter/public_html/resources/views/front/sitemap.blade.php ENDPATH**/ ?>