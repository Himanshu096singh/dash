
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-9">
        <div class="main-content p-3 p-md-5 pb-md-2 m-md-1">
            <div class="error mb-4">
                <div class="error_title blog_title mb-5">
                    <h1 class="text-center text-dark pb-3 text-uppercase"><?php echo e($brandserror->name); ?> ERRORS</h1>
                </div>
                <div class="brand_error mb-5">
                    <div class="row">
                        <div class="col-12">
                            <input class="myfilterinp" type="text" id="filterInp" onkeyup="issueSearch()" placeholder="Search for issues..">
                        </div>
                        <?php if(count($brandserror->error)>0): ?>
                        <?php $__currentLoopData = $brandserror->error; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-12 errors">
                            <div class="errror_single mb-3">
                                <div class="error_title p-3">
                                    <h3 class="h5 fw-bold p-3 bg-<?php echo e($brandserror->slug); ?> text-white"> Issue <?php echo e($index+1); ?>: <?php echo e($list->name); ?> </h3>
                                    <p><?php echo $list->description; ?></p>
                                    <div class="row brand_blog_info">
                                        <div class="col-6 text-start">
                                            <a href="<?php echo e(route('support')); ?>" class="btn btn-success p-2 h-100 d-flex justify-content-center align-items-center">
                                                <span class="text-light">
                                                    Chat Live Support Team &nbsp;<i class="fas fa-comment text-white"></i>
                                                </span>
                                            </a>
                                        </div>
                                        <div class="col-6 text-end">
                                            <a class="btn btn-info h-100 p-2 d-flex justify-content-center align-items-center openMyForm222">
                                                <span class="text-light">
                                                    Fix Your Issue &nbsp;<i class="fas fa-tools text-white"></i>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <hr>
                                    <span><i class="fas fa-user"></i> 3K Customer Satisfied</span>
                                </div> 
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <div class="col-md-12">
                            <h3> Not Found </h3>     
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
    <?php echo $__env->make('front.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    const issueSearch = () => {
  const filter = document.getElementById("filterInp").value.toUpperCase();
  const errors = document.getElementsByClassName("errors");

  Array.from(errors).forEach((error) => {
    const issueTitle = error.querySelector("h3");
    if (issueTitle) {
      const txtValue = issueTitle.textContent || issueTitle.innerText;
      error.style.display = txtValue.toUpperCase().includes(filter) ? "" : "none";
    }
  });
};
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/wirelessprinter/public_html/resources/views/front/errors.blade.php ENDPATH**/ ?>