<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="sp_container sp_container_hp bg-image bg-overlay">
    <div class="row">
        <div class="col-md-7">
            <div class="p-3">
                <div class="mb-4">
                    <h1 class="fs-2 text-light mb-4 font-weight-bold " style="font-weight:500;margin-bottom:10px !important">
                    Ask our Available EXPERTS
                    </h1>
                    <h5 class="text-light">Start Instant Chat 24/7</h5>
                </div>
                <ul class="text-light fs-6">
                    <li class="text-white">
                        Ask any technical questions, No Prepayment Required.
                    </li>
                    <li class="text-white">
                        Get your Issue fixed.
                    </li>
                    <li class="text-white">
                        No Charges unless you purchase services of subscription.
                    </li>
                    <li class="text-white">
                        Online assistance Available 24/7.
                    </li>
                </ul>
            </div>
        </div>
        <div class="col-md-5 d-none d-md-block">
            <div style="box-shadow: 0px 0px 11px #ffffff;border: 1px solid #ffffff;" class="mt-3">
                <div class="d-flex align-items-center p-3 bg-support-sec" style="border: 1px solid #ffffff;border-bottom: 1px solid #ffffff00;">
                   <img src="https://printertales.com/public/upload/image/644123f7252ae_customer-support.png" alt="Printer Support" width="80px" class="rounded-circle me-4 agentimg" >
                    <div>
                        <p class="mb-0 fs-5 fw-bold text-light">Alex M.</p>
                        <p class="text-light fsize-14">Expert, 8 years of experience helping people like you</p>
                    </div>
                   
                </div>
                <iframe style="border-radius:0px 0px 15px 15px;background: #f3f3f3;padding: 4px 6px;" class="" src="<?php echo e($code->tawktourl); ?>" width="100%" height="550px" frameborder="0" marginheight="0" marginwidth="0"></iframe>
                <div class="p-2">
                    <h6 class="text-danger">3 EXPERTS are available to chat</h6>
                    <p><i>Start typing above and press Enter to connect with them.</i></p>
                </div>
            </div>
            <span id="fp_tooltip" class="fp_tooltip">Describe your issue here.</span>
        </div>
    </div>
</div>
<div class="row ">
    <div class="p-3 py-3 d-sm-block d-md-none">
        <div style="box-shadow: 0px 0px 11px #ffffff;border: 1px solid #ffffff;" class="mt-3">
            <div class="d-flex align-items-center p-3 bg-support-sec" style="border: 1px solid #ffffff;border-bottom: 1px solid #ffffff00;">
               <img src="https://printertales.com/public/upload/image/644123f7252ae_customer-support.png" alt="Printer Support" width="80px" class="rounded-circle me-4 agentimg" >
                <div>
                    <p class="mb-0 fs-5 fw-bold text-light">Alex M.</p>
                    <p class="text-light fsize-14">Expert, 8 years of experience helping people like you</p>
                </div>
               
            </div>
            <iframe style="border-radius:0px 0px 15px 15px" class="" src="<?php echo e($code->tawktourl); ?>" width="100%" height="550px" frameborder="0" marginheight="0" marginwidth="0"></iframe>
            <div class="p-2">
                <h6 class="text-danger">3 EXPERTS are available to chat</h6>
                <p><i>Start typing above and press Enter to connect with them.</i></p>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-7 p-3 py-3 ">
        <div class="row text-center">
            <h2 class="h3 mb-3"> Frequently Asked Questions </h2>
        </div>
        <div class="accordion" id="accordionExample">
            <?php $__currentLoopData = $supportfaq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="accordion-item">
              <h2 class="accordion-header" id="heading<?php echo e($index); ?>">
                <button class="accordion-button <?php echo e($index==0 ? '' : 'collapsed'); ?>" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($index); ?>"
                  aria-expanded="<?php echo e($index==0 ? 'true' : 'false'); ?>" aria-controls="collapse<?php echo e($index); ?>">
                  <?php echo e($list->question); ?>

                </button>
              </h2>
              <div id="collapse<?php echo e($index); ?>" class="accordion-collapse collapse <?php echo e($index==0 ? 'show' : ''); ?>" aria-labelledby="heading<?php echo e($index); ?>"
                data-bs-parent="#accordionExample">
                <div class="accordion-body">
                  <?php echo $list->answer; ?>

                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
          </div>
    </div>
    
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/wirelessprinter/bluetoothprintersetup.com/resources/views/front/support.blade.php ENDPATH**/ ?>