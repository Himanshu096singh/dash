<!doctype html>
<html>
<head>
   <meta charset="utf-8">
   <meta http-equiv="x-ua-compatible" content="ie=edge">
   <title></title>
   <meta name="description" content="">
</head>
<body>
    <table>
        <tr>
            <th style="text-align:left">Issue :</th>
            <td><?php echo e($mailData['issue']); ?></td>
        </tr>
        <tr>
            <th style="text-align:left">Device :</th>
            <td><?php echo e($mailData['device']); ?></td>
        </tr>
        <tr>
            <th style="text-align:left">Software :</th>
            <td><?php echo e($mailData['software']); ?></td>
        </tr>
        <tr>
            <th style="text-align:left">Email :</th>
            <td><?php echo e($mailData['email']); ?></td>
        </tr>
        <tr>
            <th style="text-align:left">Mobile :</th>
            <td><?php echo e($mailData['countrycode'].' '.$mailData['mobile']); ?></td>
        </tr>
        <tr>
            <th style="text-align:left">IP Address :</th>
            <td><?php echo e(Request::ip()); ?></td>
        </tr>
    </table>
</body>
</html><?php /**PATH /home3/wirelessprinter/public_html/resources/views/mail/email.blade.php ENDPATH**/ ?>