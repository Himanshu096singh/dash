<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
   <div class="col-md-9">
      <div class="main-content p-3 p-md-5 pb-md-2 m-md-1">
         <div class="brand mb-4">
            <div class="brand_title blog_title mb-5">
               <h1 class="text-center text-dark pb-3 text-uppercase"><?php echo e($category->name); ?> <?php echo e($subcategory->name); ?></h1>
            </div>
            <?php if(count($subcategory->blogs)>0): ?>
                <div class="brand_blog mb-5">
                    <div class="row">
                        <div class="mb-5">
                          <h2 class="h3"> Latest <span class="px-3 text-light bg-<?php echo e($category->slug); ?>"><?php echo e($category->name); ?> <?php echo e($subcategory->name); ?></span> Blog </h2>
                        </div>
                        <?php $__currentLoopData = $subcategory->blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <div class="brand_blog_box mb-3">
                                    <a href="<?php echo e($category->slug .'/'. $list->slug); ?>" title="<?php echo e($list->name); ?>">
                                        <img src="<?php echo e(asset($list->image)); ?>" alt="<?php echo e($list->alt); ?>" class="img-fluid">
                                    </a>
                                    
                                    <div class="brand_blog_title p-3">
                                        
                                        <h3 class="p fw-bold pb-2">
                                          <a href="<?php echo e($list->slug); ?>" title="<?php echo e($list->name); ?>" class="text-muted text-decoration-none"> <?php echo e($list->name); ?> </a>
                                        </h3>
                                      <div class="row brand_blog_info">
                                        <div class="col-6 text-start"><span>Added to <span class="fw-bold"><?php echo e($category->name); ?></span></span></div>
                                        <div class="col-6 text-end"><spanp> <?php echo e($list->created_at->format('M, d Y')); ?> </spanp></div>
                                      </div>
                                      <hr>
                                      <span> <i class="fas fa-user"></i>  By <?php echo e($list->user->name); ?> </span>
                                    </div> 
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
            <?php if(count($subcategory->products)>0): ?>
            <div class="brand_product latesthomeproduct mb-3">
                <div class="mb-5">
                  <h2 class="h3"> Latest <span class="px-3 text-light bg-<?php echo e($category->slug); ?>"><?php echo e($category->name); ?> <?php echo e($subcategory->name); ?></span> Printer </h2>
                </div>
                <div class="row"> 
                    <?php $__currentLoopData = $subcategory->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-3">
                            
                                <div class="position-relative product-image">
                                    <a href= "<?php echo e(url($list->category->slug. "/" .$list->slug)); ?>" title="<?php echo e($list->name); ?>">
                                        <img src="<?php echo e(asset($list->image)); ?>" alt="<?php echo e($list->alt); ?>" class="img-fluid rounded-2">
                                    </a>
                                    <a class="text-decoration-none position-absolute fs-6 badge bg-<?php echo e($list->category->slug); ?> product-brand-name text-uppercase fw-normal" href="#">  <?php echo e($list->category->name); ?> </a> 
                                </div>
                                <a href= "<?php echo e(url($list->category->slug. "/" .$list->slug)); ?>" title="<?php echo e($list->name); ?>" class="text-decoration-none text-muted">
                                    <h3 class="fs-14 text-uppercase text-center pt-3 pb-0"> 
                                      <?php echo e($list->name); ?>

                                    </h3>
                                    <div class="product-review text-center">
                                      <i class="fas fa-star color-<?php echo e($list->category->slug); ?>"></i>
                                      <i class="fas fa-star color-<?php echo e($list->category->slug); ?>"></i>
                                      <i class="fas fa-star color-<?php echo e($list->category->slug); ?>"></i>
                                      <i class="fas fa-star color-<?php echo e($list->category->slug); ?>"></i>
                                      <i class="fas fa-star color-<?php echo e($list->category->slug); ?>"></i>
                                    </div>
                                </a>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="brand_description mb-5">
              <h2 class="h3"> About <span class="px-3 text-light bg-<?php echo e($category->slug); ?>"><?php echo e($category['name']); ?> <?php echo e($subcategory->name); ?></span> </h2> 
              <hr>
              
              <?php echo $subcategory['description']; ?>

            </div>
           
            <?php if(count($subcategory->faq)>0): ?>
                <div class="brand_faqs ">
                    <h2> Frequently Asked Questions </h2> 
                    <hr>
                    <div class="">
                        <?php $__currentLoopData = $subcategory->faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="brand_faqs_qa bg-white">
                            <div class="faqs_question">
                                <h6><span class="badge bg-<?php echo e($category->slug); ?>"> Question </span></h6>
                                <h3><?php echo e($list->question); ?></h3>
                            </div>
                            <div class="faqs_answer">
                                <?php echo $list->answer; ?>

                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
         </div>
      </div>
   </div>
   <div class="col-md-3">
       <?php echo $__env->make('front.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/wirelessprinter/public_html/resources/views/front/subcategorydetails.blade.php ENDPATH**/ ?>