<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "<?php echo e($setting->name); ?>",
  "image": "<?php echo e(asset($setting->logo)); ?>",
  "@id": "<?php echo e(route('home')); ?>",
  "url": "<?php echo e(route('home')); ?>",
  "telephone": "<?php echo e($setting->usmobile); ?>",
  "priceRange": "US",
  "openingHoursSpecification": {
    "@type": "OpeningHoursSpecification",
    "dayOfWeek": [
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
      "Sunday"
    ],
    "opens": "00:00",
    "closes": "23:59"
  },
  "sameAs": [
        "<?php echo e(route('home')); ?>"] 
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "<?php echo e($setting->name); ?>",
  "alternateName": "<?php echo e($setting->name); ?>",
  "url": "<?php echo e(route('home')); ?>",
  "logo": "<?php echo e(asset($setting->logo)); ?>",
  "sameAs": [
        "<?php echo e(route('home')); ?>"
        ]
}
</script>
<script type="application/ld+json">
    {
      "@context" : "https://schema.org",
      "@type" : "WebSite",
      "name" : "<?php echo e($setting->name); ?>",
      "alternateName" : "WPO",
      "url" : "<?php echo e(route('home')); ?>"
    }
  </script>
<?php if(isset($meta) && isset($meta['type']) && $meta['type']=='blog'): ?>
    <script type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "BlogPosting",
          "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": ""
          },
          "headline": "<?php echo e($blog->name); ?>",
          "description": "<?php echo e($blog->metadescription); ?>",
          "image": "<?php echo e(asset($blog->image)); ?>",  
          "author": {
            "@type": "Person",
            "name": "<?php echo e($blog->user->name); ?>",
            "url": ""
          },  
          "publisher": {
            "@type": "Organization",
            "name": "<?php echo e($setting->name); ?>",
            "logo": {
              "@type": "ImageObject",
              "url":"<?php echo e(asset($setting->logo)); ?>"
            }
          },
          "datePublished": "2023-04-05 09:37:24"
        }
    </script>
    <?php if(count($blog->faqs)>0): ?>
    <script type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "FAQPage",
          "mainEntity": [
                <?php $__currentLoopData = $blog->faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    "@type": "Question",
                    "name": "<?php echo e($list->question); ?>",
                    "acceptedAnswer": {
                      "@type": "Answer",
                      "text": "<?php echo e(strip_tags($list->answer)); ?>"
                    }
                }<?php echo e(($index<count($blog->faqs)-1) ? "," : ""); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ] 
        }
        </script>
    <?php endif; ?>
<?php endif; ?>

<?php if(isset($meta) && isset($meta['type']) && $meta['type']=='category'): ?>
    
    <?php if(count($category->faqs)>0): ?>
    <script type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "FAQPage",
          "mainEntity": [
                <?php $__currentLoopData = $category->faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    "@type": "Question",
                    "name": "<?php echo e($list->question); ?>",
                    "acceptedAnswer": {
                      "@type": "Answer",
                      "text": "<?php echo e(strip_tags($list->answer)); ?>"
                    }
                }<?php echo e(($index<count($category->faqs)-1) ? "," : ""); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ] 
        }
        </script>
    <?php endif; ?>
<?php endif; ?>

<?php if(isset($meta) && isset($meta['type']) && $meta['type']=='subcategory'): ?>
    
    <?php if(count($subcategory->faq)>0): ?>
    <script type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "FAQPage",
          "mainEntity": [
                <?php $__currentLoopData = $subcategory->faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    "@type": "Question",
                    "name": "<?php echo e($list->question); ?>",
                    "acceptedAnswer": {
                      "@type": "Answer",
                      "text": "<?php echo e(strip_tags($list->answer)); ?>"
                    }
                }<?php echo e(($index<count($subcategory->faq)-1) ? "," : ""); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ] 
        }
        </script>
    <?php endif; ?>
<?php endif; ?>

<?php if(isset($meta) && isset($meta['type']) && $meta['type']=='product'): ?>
    
    <script type="application/ld+json">
        {
         "@context": "https://schema.org/", 
         "@type": "Product", 
         "name": "<?php echo e($product->name); ?>",
         "image": "<?php echo e(asset($product->image)); ?>",
         "description": "<?php echo e($product->metadescription); ?>",
         "brand": {
            "@type": "Brand",
            "name": "<?php echo e($product->category->name); ?>"
         },
        "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "4.5",
            "bestRating": "5",
            "worstRating": "1",
            "ratingCount": "18"
         }
        } 
    </script>
        
    <?php if(count($product->faqs)>0): ?>
    <script type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "FAQPage",
          "mainEntity": [
                <?php $__currentLoopData = $product->faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    "@type": "Question",
                    "name": "<?php echo e($list->question); ?>",
                    "acceptedAnswer": {
                      "@type": "Answer",
                      "text": "<?php echo e(strip_tags($list->answer)); ?>"
                    }
                }<?php echo e(($index<count($product->faqs)-1) ? "," : ""); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ] 
        }
        </script>
    <?php endif; ?>
<?php endif; ?>
    <?php /**PATH /home3/wirelessprinter/bluetoothprintersetup.com/resources/views/front/include/schema.blade.php ENDPATH**/ ?>