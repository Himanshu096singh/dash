<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
          <div class="main-content p-3 p-md-5 pb-md-2 m-md-1">
             <div class="blog_single mb-4">
                <div class="page_title blog_title mb-5">
                   <h1 class=" text-center text-dark pb-3"><?php echo e($page->name); ?></h1>
                </div>
                <div class="description">
                    <?php echo $page->description; ?>

                </div>
             </div>
          </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/wirelessprinter/public_html/resources/views/front/staticpage.blade.php ENDPATH**/ ?>