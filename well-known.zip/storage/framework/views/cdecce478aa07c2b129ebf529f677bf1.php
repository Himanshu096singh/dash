<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-9">
        <div class="main-content p-3 p-md-5 m-md-1"> 
        <h1 class="text-center">Help Guides by <?php echo e($setting->name); ?></h1>
        <hr/> 
          <div class="latesthomeblog mt-5 mb-5">
            <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bp-single mb-4">
                    <a href="<?php echo e(url($list->category->slug. "/". $list->slug)); ?>" target="_blank" title="<?php echo e($list->name); ?>"> 
                    <h3 class="h4"> <?php echo e($list->name); ?>  </h3>
                        <p>
                            <?php echo substr(strip_tags($list->description),0,180); ?>...
                        </p>
                    </a>
                </div>
                <?php if($key==2): ?>
                    <div class="gif_img">
                        <a href="<?php echo e(route('support')); ?>">
                            <img class="img-fluid pb-3 cgif" src="<?php echo e(asset('assets/images/printer-offline-gif-2.gif')); ?>" alt="Fix your pritner now">
                        </a>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </div>
            <?php if(count($product)>0 ): ?>
            <div class="latesthomeproduct mb-3">
                <div class="mb-5 text-center">
                  <h2> Printer Models We Fix </h2>
                </div>
                <div class="row"> 
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 mb-3">
                        
                            <div class="position-relative product-image">
                                <a href= "<?php echo e(url($list->category->slug. "/" .$list->slug)); ?>" title="<?php echo e($list->name); ?>">
                                    <img src="<?php echo e(asset($list->image)); ?>" alt="<?php echo e($list->alt); ?>" class="img-fluid rounded-2">
                                </a>
                                <a class="text-decoration-none position-absolute fs-6 badge bg-<?php echo e($list->category->slug); ?> product-brand-name text-uppercase fw-normal" href="#">  <?php echo e($list->category->name); ?> </a> 
                            </div>
                            <a href= "<?php echo e(url($list->category->slug. "/" .$list->slug)); ?>" title="<?php echo e($list->name); ?>" class="text-decoration-none text-muted">
                                <h3 class="fs-14 text-uppercase text-center pt-3 pb-0"> 
                                  <?php echo e($list->name); ?>

                                </h3>
                                <div class="product-review text-center">
                                  <i class="fas fa-star color-<?php echo e($list->category->slug); ?>"></i>
                                  <i class="fas fa-star color-<?php echo e($list->category->slug); ?>"></i>
                                  <i class="fas fa-star color-<?php echo e($list->category->slug); ?>"></i>
                                  <i class="fas fa-star color-<?php echo e($list->category->slug); ?>"></i>
                                  <i class="fas fa-star color-<?php echo e($list->category->slug); ?>"></i>
                                </div>
                            </a>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-3"> 
      <?php echo $__env->make('front.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/wirelessprinter/connectprintertowifi.com/resources/views/front/home.blade.php ENDPATH**/ ?>