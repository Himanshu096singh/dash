@extends('layouts.back')
@section('content')
<!-- BEGIN : Main Content-->
<div class="main-content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-12">
                <div class="content-header">
                    Setting
                </div>
            </div>
        </div>
        <section id="basic-hidden-label-form-layouts">
            <div class="row match-height">
                <div class="col-lg-12 col-md-12 col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Setting</h4>
                        </div>
                        <div class="card-content">
                            <div class="card-body">
                                <form method="post" action="{{ route('addsetting') }}" enctype="multipart/form-data">
                                    @csrf
                                    <div class="form-row">
                                        <div class="col-md-6 col-12">
                                            <div class="form-group mb-2">
                                                <label for="name">Name</label>
                                                <input class="form-control @error('name') is-invalid @enderror" id="name" name="name" type="text" placeholder="Name" value="{{ old('name', $setting->name) }}">
                                                @error('name')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group mb-2">
                                                <label for="url">Url</label>
                                                <input class="form-control @error('url') is-invalid @enderror" id="url" name="url" type="text" placeholder="Url" value="{{ old('url' ,$setting->url) }}">
                                                @error('url')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group mb-2">
                                                <label for="email">Email</label>
                                                <input class="form-control @error('email') is-invalid @enderror" id="email" name="email" type="email" placeholder="Email" value="{{ old('email', $setting->email) }}">
                                                @error('email')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="row">
                                                <div class="col-md-6 col-12">
                                                    <div class="form-group mb-2">
                                                        <label for="usmobile">US Mobile No.</label>
                                                        <input class="form-control @error('usmobile') is-invalid @enderror" id="usmobile" name="usmobile" type="text" placeholder="US Mobile No." value="{{ old('usmobile', $setting->usmobile) }}">
                                                        @error('usmobile')
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong>{{ $message }}</strong>
                                                            </span>
                                                        @enderror
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-12">
                                                    <div class="form-group mb-2">
                                                        <label for="ukmobile">UK Mobile No.</label>
                                                        <input class="form-control @error('ukmobile') is-invalid @enderror" id="ukmobile" name="ukmobile" type="text" placeholder="UK Mobile No." value="{{ old('ukmobile', $setting->ukmobile) }}">
                                                        @error('ukmobile')
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong>{{ $message }}</strong>
                                                            </span>
                                                        @enderror
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group mb-2">
                                                <label for="logo">Logo</label>
                                                <img src="{{ asset($setting->logo) }}" alt="{{ $setting->logoalt }}" width="100">
                                                <input class="form-control @error('logo') is-invalid @enderror" id="logo" name="logo" type="file">
                                                @error('logo')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group mb-2">
                                                <label for="logoalt">Logo Alt</label>
                                                <input class="form-control @error('logoalt') is-invalid @enderror" id="logoalt" name="logoalt" type="text" placeholder="logoalt" value="{{ old('logoalt', $setting->logoalt) }}">
                                                @error('logoalt')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group mb-2">
                                                <label for="fevicon">Fevicon</label>
                                                <img src="{{ asset($setting->fevicon) }}" alt="{{ $setting->fevalt }}" width="100">
                                                <input class="form-control @error('fevicon') is-invalid @enderror" id="fevicon" name="fevicon" type="file">
                                                @error('fevicon')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group mb-2">
                                                <label for="fevalt">Fevicon Alt</label>
                                                <input class="form-control @error('fevalt') is-invalid @enderror" id="fevalt" name="fevalt" type="text" placeholder="fevalt" value="{{ old('fevalt', $setting->fevalt) }}">
                                                @error('fevalt')
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <label for="email">Robots</label>
                                            <div class="form-group mb-2">
                                                <div class="radio radio-success @error('robots') is-invalid @enderror">
                                                    <input type="radio" name="robots" id="robots1" value="1" {{ old('robots', $setting->robots) == 1 ? 'checked':'' }}>
                                                    <label for="robots1">Index</label>
                                                </div>
                                            </div>
                                            <div class="form-group mb-2">
                                                <div class="radio radio-danger @error('status') is-invalid @enderror">
                                                    <input type="radio" name="robots" id="robots2" value="0" {{ old('robots', $setting->robots) == 0 ? 'checked':'' }}>
                                                    <label for="robots2">No Index</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group mb-2">
                                        <label for="disclaimer">Description</label>
                                        <textarea class="form-control" name="disclaimer" id="disclaimer">{{ $setting->disclaimer }}</textarea>
                                        @error('disclaimer')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                    <button class="btn btn-primary mr-2" type="submit">
                                        <i class="ft-check-square mr-1"></i>Save
                                    </button>
                                    <a href="{{ URL::previous() }}">
                                        <button class="btn btn-secondary" type="button">
                                            <i class="ft-x mr-1"></i>Back
                                        </button>
                                    </a>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
@endsection
